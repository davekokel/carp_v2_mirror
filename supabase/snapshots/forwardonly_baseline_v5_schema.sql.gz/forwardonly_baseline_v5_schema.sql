--
-- PostgreSQL database dump
--

\restrict Lgo2O0ednJ7eIg10vMrj4940YRdasAFbpMXr5ObWeWczihQtzQp2wK5YY6a9wYO

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.treated_clutches DROP CONSTRAINT IF EXISTS treated_clutches_clutch_instance_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transgene_alleles DROP CONSTRAINT IF EXISTS transgene_alleles_transgene_base_code_fkey;
ALTER TABLE IF EXISTS ONLY public.tanks DROP CONSTRAINT IF EXISTS tanks_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tank_pairs DROP CONSTRAINT IF EXISTS tank_pairs_mother_tank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tank_pairs DROP CONSTRAINT IF EXISTS tank_pairs_father_tank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.plates DROP CONSTRAINT IF EXISTS plates_format_code_fkey;
ALTER TABLE IF EXISTS ONLY public.plate_slots DROP CONSTRAINT IF EXISTS plate_slots_treated_clutch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.plate_slots DROP CONSTRAINT IF EXISTS plate_slots_plate_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_plasmid_fusions DROP CONSTRAINT IF EXISTS join_plasmid_fusions_plasmid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_plasmid_fusions DROP CONSTRAINT IF EXISTS join_plasmid_fusions_fusion_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_transgene_alleles DROP CONSTRAINT IF EXISTS join_fish_transgene_alleles_transgene_base_code_fkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_transgene_alleles DROP CONSTRAINT IF EXISTS join_fish_transgene_alleles_fish_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_fluorescent_treatments DROP CONSTRAINT IF EXISTS join_fish_fluorescent_treatments_ft_code_fkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_fluorescent_treatments DROP CONSTRAINT IF EXISTS join_fish_fluorescent_treatments_fish_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_dyes_fluorescent_treatments DROP CONSTRAINT IF EXISTS join_dyes_fluorescent_treatments_ft_code_fkey;
ALTER TABLE IF EXISTS ONLY public.join_dyes_fluorescent_treatments DROP CONSTRAINT IF EXISTS join_dyes_fluorescent_treatments_dye_code_fkey;
ALTER TABLE IF EXISTS ONLY public.join_clutch_treatments DROP CONSTRAINT IF EXISTS join_clutch_treatments_treated_clutch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_clutch_treatments DROP CONSTRAINT IF EXISTS join_clutch_treatments_clutch_instance_id_fkey;
ALTER TABLE IF EXISTS ONLY public.join_annotations DROP CONSTRAINT IF EXISTS join_annotations_annotation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fusions DROP CONSTRAINT IF EXISTS fusions_tag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fusions DROP CONSTRAINT IF EXISTS fusions_fluor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fusions DROP CONSTRAINT IF EXISTS fusions_dye_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ft_proteins DROP CONSTRAINT IF EXISTS ft_proteins_tag_code_fkey;
ALTER TABLE IF EXISTS ONLY public.ft_proteins DROP CONSTRAINT IF EXISTS ft_proteins_ft_code_fkey;
ALTER TABLE IF EXISTS ONLY public.ft_proteins DROP CONSTRAINT IF EXISTS ft_proteins_fluor_code_fkey;
ALTER TABLE IF EXISTS ONLY public.ft_dyes DROP CONSTRAINT IF EXISTS ft_dyes_ft_code_fkey;
ALTER TABLE IF EXISTS ONLY public.ft_dyes DROP CONSTRAINT IF EXISTS ft_dyes_dye_code_fkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_transgene_alleles DROP CONSTRAINT IF EXISTS fk_jfta_ta;
ALTER TABLE IF EXISTS ONLY public.clutch_instances DROP CONSTRAINT IF EXISTS clutch_instances_cross_instance_id_fkey;
DROP TRIGGER IF EXISTS trg_treated_clutches_bi_assign_code ON public.treated_clutches;
DROP TRIGGER IF EXISTS trg_tc_ai_baseline ON public.clutch_instances;
DROP TRIGGER IF EXISTS trg_tanks_bi_set_defaults ON public.tanks;
DROP TRIGGER IF EXISTS trg_tank_pairs_bi_assign_code ON public.tank_pairs;
DROP TRIGGER IF EXISTS trg_plates_bi_assign_code ON public.plates;
DROP TRIGGER IF EXISTS trg_jct_bi_norm ON public.join_clutch_treatments;
DROP TRIGGER IF EXISTS trg_jct_bi_assign_group ON public.join_clutch_treatments;
DROP TRIGGER IF EXISTS trg_ja_biu_enforce_scale_100 ON public.join_annotations;
DROP TRIGGER IF EXISTS trg_fusions_set_code_before_insert ON public.fusions;
DROP TRIGGER IF EXISTS trg_ft_proteins_normalize ON public.ft_proteins;
DROP TRIGGER IF EXISTS trg_fish_code_default ON public.fish;
DROP TRIGGER IF EXISTS trg_crosses_bi_assign_code ON public.crosses;
DROP TRIGGER IF EXISTS trg_clutch_instances_bi_assign_fields ON public.clutch_instances;
CREATE OR REPLACE VIEW public.v_plasmids AS
SELECT
    NULL::uuid AS id,
    NULL::text AS code,
    NULL::text AS name,
    NULL::text AS nickname,
    NULL::text AS resistance,
    NULL::boolean AS supports_invitro_rna,
    NULL::text AS notes,
    NULL::text AS created_by,
    NULL::timestamp with time zone AS created_at,
    NULL::text AS fluors,
    NULL::text AS tags,
    NULL::text AS fusions,
    NULL::text[] AS fluors_arr,
    NULL::text[] AS tags_arr,
    NULL::text[] AS fusions_arr;
DROP INDEX IF EXISTS public.uq_treated_clutches_code;
DROP INDEX IF EXISTS public.uq_tanks_tank_code;
DROP INDEX IF EXISTS public.uq_tags_name_lower;
DROP INDEX IF EXISTS public.uq_ta_base_nickname_norm;
DROP INDEX IF EXISTS public.uq_plate_slots_loc;
DROP INDEX IF EXISTS public.uq_plasmids_code;
DROP INDEX IF EXISTS public.uq_join_plasmid_fusions_plasmid_fusion;
DROP INDEX IF EXISTS public.uq_join_plasmid_fusions_ids;
DROP INDEX IF EXISTS public.uq_fusions_tag_only;
DROP INDEX IF EXISTS public.uq_fusions_tag_fluor;
DROP INDEX IF EXISTS public.uq_fusions_name_fluor_tag_nd;
DROP INDEX IF EXISTS public.uq_fusions_fluor_tag_nd;
DROP INDEX IF EXISTS public.uq_ft_proteins_ft_tag_fluor;
DROP INDEX IF EXISTS public.uq_ft_proteins_ft_fluor_tag_norm;
DROP INDEX IF EXISTS public.uq_ft_proteins_ft_fluor_tag_nd;
DROP INDEX IF EXISTS public.uq_fluors_name_lower;
DROP INDEX IF EXISTS public.uq_crosses_pair_date;
DROP INDEX IF EXISTS public.uq_clutches_cross_normgeno;
DROP INDEX IF EXISTS public.ix_treated_clutches_ci;
DROP INDEX IF EXISTS public.ix_join_annotations_ttype_tid_aid_val;
DROP INDEX IF EXISTS public.ix_join_annotations_target;
DROP INDEX IF EXISTS public.ix_join_annotations_annotation;
DROP INDEX IF EXISTS public.ix_jfta_base_num;
DROP INDEX IF EXISTS public.ix_jct_clutch_instance_id;
DROP INDEX IF EXISTS public.idx_fluors_name_ci;
DROP INDEX IF EXISTS public.idx_dyes_name_ci;
ALTER TABLE IF EXISTS ONLY public.treated_clutches DROP CONSTRAINT IF EXISTS uq_treated_clutch_code;
ALTER TABLE IF EXISTS ONLY public.tank_pairs DROP CONSTRAINT IF EXISTS uq_tank_pairs_code;
ALTER TABLE IF EXISTS ONLY public.join_clutch_treatments DROP CONSTRAINT IF EXISTS uq_jct_by_group_kind_code;
ALTER TABLE IF EXISTS ONLY public.treatments DROP CONSTRAINT IF EXISTS treatments_pkey;
ALTER TABLE IF EXISTS ONLY public.treatments_physical DROP CONSTRAINT IF EXISTS treatments_physical_pkey;
ALTER TABLE IF EXISTS ONLY public.treatments_fluorescent DROP CONSTRAINT IF EXISTS treatments_fluorescent_pkey;
ALTER TABLE IF EXISTS ONLY public.treatments_chemical DROP CONSTRAINT IF EXISTS treatments_chemical_pkey;
ALTER TABLE IF EXISTS ONLY public.treated_clutches DROP CONSTRAINT IF EXISTS treated_clutches_pkey;
ALTER TABLE IF EXISTS ONLY public.transgenes DROP CONSTRAINT IF EXISTS transgenes_pkey;
ALTER TABLE IF EXISTS ONLY public.transgene_alleles DROP CONSTRAINT IF EXISTS transgene_alleles_pkey;
ALTER TABLE IF EXISTS ONLY public.tanks DROP CONSTRAINT IF EXISTS tanks_tank_code_key;
ALTER TABLE IF EXISTS ONLY public.tanks DROP CONSTRAINT IF EXISTS tanks_pkey;
ALTER TABLE IF EXISTS ONLY public.tank_pairs DROP CONSTRAINT IF EXISTS tank_pairs_tank_pair_code_key;
ALTER TABLE IF EXISTS ONLY public.tank_pairs DROP CONSTRAINT IF EXISTS tank_pairs_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_tag_code_key;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_pkey;
ALTER TABLE IF EXISTS ONLY public.plates DROP CONSTRAINT IF EXISTS plates_plate_code_key;
ALTER TABLE IF EXISTS ONLY public.plates DROP CONSTRAINT IF EXISTS plates_pkey;
ALTER TABLE IF EXISTS ONLY public.plate_slots DROP CONSTRAINT IF EXISTS plate_slots_pkey;
ALTER TABLE IF EXISTS ONLY public.plate_formats DROP CONSTRAINT IF EXISTS plate_formats_pkey;
ALTER TABLE IF EXISTS ONLY public.plasmids DROP CONSTRAINT IF EXISTS plasmids_pkey;
ALTER TABLE IF EXISTS ONLY public.plasmids DROP CONSTRAINT IF EXISTS plasmids_code_key;
ALTER TABLE IF EXISTS ONLY public.locations DROP CONSTRAINT IF EXISTS locations_pkey;
ALTER TABLE IF EXISTS ONLY public.locations DROP CONSTRAINT IF EXISTS locations_code_key;
ALTER TABLE IF EXISTS ONLY public.join_plasmid_fusions DROP CONSTRAINT IF EXISTS join_plasmid_fusions_pkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_transgene_alleles DROP CONSTRAINT IF EXISTS join_fish_transgene_alleles_pkey;
ALTER TABLE IF EXISTS ONLY public.join_fish_fluorescent_treatments DROP CONSTRAINT IF EXISTS join_fish_fluorescent_treatments_pkey;
ALTER TABLE IF EXISTS ONLY public.join_dyes_fluorescent_treatments DROP CONSTRAINT IF EXISTS join_dyes_fluorescent_treatments_pkey;
ALTER TABLE IF EXISTS ONLY public.join_clutch_treatments DROP CONSTRAINT IF EXISTS join_clutch_treatments_pkey;
ALTER TABLE IF EXISTS ONLY public.join_annotations DROP CONSTRAINT IF EXISTS join_annotations_pkey;
ALTER TABLE IF EXISTS ONLY public.fusions DROP CONSTRAINT IF EXISTS fusions_pkey;
ALTER TABLE IF EXISTS ONLY public.fusions DROP CONSTRAINT IF EXISTS fusions_fusion_code_key;
ALTER TABLE IF EXISTS ONLY public.ft_proteins DROP CONSTRAINT IF EXISTS ft_proteins_pkey;
ALTER TABLE IF EXISTS ONLY public.ft_dyes DROP CONSTRAINT IF EXISTS ft_dyes_pkey;
ALTER TABLE IF EXISTS ONLY public.fluors DROP CONSTRAINT IF EXISTS fluors_pkey;
ALTER TABLE IF EXISTS ONLY public.fluors DROP CONSTRAINT IF EXISTS fluors_fluor_code_key;
ALTER TABLE IF EXISTS ONLY public.fish DROP CONSTRAINT IF EXISTS fish_pkey;
ALTER TABLE IF EXISTS ONLY public.fish DROP CONSTRAINT IF EXISTS fish_fish_code_key;
ALTER TABLE IF EXISTS ONLY public.dyes DROP CONSTRAINT IF EXISTS dyes_pkey;
ALTER TABLE IF EXISTS ONLY public.dyes DROP CONSTRAINT IF EXISTS dyes_dye_code_key;
ALTER TABLE IF EXISTS ONLY public.crosses DROP CONSTRAINT IF EXISTS crosses_pkey;
ALTER TABLE IF EXISTS ONLY public.clutch_instances DROP CONSTRAINT IF EXISTS clutch_instances_pkey;
ALTER TABLE IF EXISTS ONLY public.annotations DROP CONSTRAINT IF EXISTS annotations_pkey;
ALTER TABLE IF EXISTS ONLY public.annotations DROP CONSTRAINT IF EXISTS annotations_kind_code_key;
DROP VIEW IF EXISTS public.v_treatments_catalog;
DROP VIEW IF EXISTS public.v_treated_clutches;
DROP VIEW IF EXISTS public.v_treated_clutch_annotations_pivot;
DROP VIEW IF EXISTS public.v_tank_pairs;
DROP VIEW IF EXISTS public.v_tanks;
DROP VIEW IF EXISTS public.v_plate_layout;
DROP VIEW IF EXISTS public.v_plasmids_rich;
DROP VIEW IF EXISTS public.v_plasmids;
DROP VIEW IF EXISTS public.v_fluorescent_treatment_markers;
DROP VIEW IF EXISTS public.v_tags_lu;
DROP VIEW IF EXISTS public.v_fluors_lu;
DROP VIEW IF EXISTS public.v_fluorescent_marker_rollup_by_base;
DROP VIEW IF EXISTS public.v_fluorescent_marker_rollup;
DROP VIEW IF EXISTS public.v_fish_unified;
DROP VIEW IF EXISTS public.v_fish_overview_id;
DROP VIEW IF EXISTS public.v_fish_marker_rollup_by_ids;
DROP VIEW IF EXISTS public.v_fish_main;
DROP VIEW IF EXISTS public.v_fish_genotype_rollup_by_ids;
DROP VIEW IF EXISTS public.v_fish_fluorescent_markers;
DROP VIEW IF EXISTS public.v_dyes_lu;
DROP VIEW IF EXISTS public.v_clutch_instances;
DROP VIEW IF EXISTS public.v_annotations_latest_group;
DROP VIEW IF EXISTS public.v_annotations_latest;
DROP TABLE IF EXISTS public.treatments_physical;
DROP TABLE IF EXISTS public.treatments_fluorescent;
DROP TABLE IF EXISTS public.treatments_chemical;
DROP TABLE IF EXISTS public.treatments;
DROP TABLE IF EXISTS public.treated_clutches;
DROP TABLE IF EXISTS public.transgenes;
DROP TABLE IF EXISTS public.transgene_alleles;
DROP TABLE IF EXISTS public.tanks;
DROP TABLE IF EXISTS public.tank_pairs;
DROP TABLE IF EXISTS public.tags;
DROP SEQUENCE IF EXISTS public.seq_treated_clutch_code;
DROP SEQUENCE IF EXISTS public.seq_tank_pair_code;
DROP SEQUENCE IF EXISTS public.seq_global_allele_number;
DROP SEQUENCE IF EXISTS public.seq_fish_code;
DROP SEQUENCE IF EXISTS public.seq_cross_run_code;
DROP SEQUENCE IF EXISTS public.seq_clutch_instance_code;
DROP TABLE IF EXISTS public.plates;
DROP SEQUENCE IF EXISTS public.seq_plate_code;
DROP TABLE IF EXISTS public.plate_slots;
DROP TABLE IF EXISTS public.plate_formats;
DROP TABLE IF EXISTS public.plasmids;
DROP TABLE IF EXISTS public.locations;
DROP TABLE IF EXISTS public.join_plasmid_fusions;
DROP TABLE IF EXISTS public.join_fish_transgene_alleles;
DROP TABLE IF EXISTS public.join_fish_fluorescent_treatments;
DROP TABLE IF EXISTS public.join_dyes_fluorescent_treatments;
DROP TABLE IF EXISTS public.join_clutch_treatments;
DROP TABLE IF EXISTS public.join_annotations;
DROP TABLE IF EXISTS public.fusions;
DROP TABLE IF EXISTS public.ft_proteins;
DROP TABLE IF EXISTS public.ft_dyes;
DROP TABLE IF EXISTS public.fluors;
DROP TABLE IF EXISTS public.fish;
DROP TABLE IF EXISTS public.dyes;
DROP TABLE IF EXISTS public.crosses;
DROP TABLE IF EXISTS public.clutch_instances;
DROP TABLE IF EXISTS public.annotations;
DROP FUNCTION IF EXISTS public.uuid_to_base36_8(p uuid);
DROP FUNCTION IF EXISTS public.upsert_transgene_allele(p_transgene_base_code text, p_allele_nickname text);
DROP FUNCTION IF EXISTS public.upsert_fusion_by_names(p_fusion_name text, p_fluor text, p_tag text);
DROP FUNCTION IF EXISTS public.upsert_fish_by_identity(p_seed_batch_id text, p_identity_key text, p_dob date, p_name_human text, p_bg text, p_nick text, p_stage text, p_desc text, p_notes text, p_by text);
DROP FUNCTION IF EXISTS public.trg_set_fish_code_from_uuid_base36_8();
DROP FUNCTION IF EXISTS public.trg_set_fish_code_base36();
DROP FUNCTION IF EXISTS public.treated_clutches_bi_assign_code();
DROP FUNCTION IF EXISTS public.treated_clutches_ai_baseline();
DROP FUNCTION IF EXISTS public.treated_clutch_code_next();
DROP FUNCTION IF EXISTS public.to_base36(n bigint);
DROP FUNCTION IF EXISTS public.tanks_bi_set_defaults();
DROP FUNCTION IF EXISTS public.tank_pairs_bi_assign_code();
DROP FUNCTION IF EXISTS public.tank_pair_code_next();
DROP FUNCTION IF EXISTS public.slugify_code(p text);
DROP FUNCTION IF EXISTS public.row_letter(p_row integer);
DROP FUNCTION IF EXISTS public.resolve_tag_id(p_token text);
DROP FUNCTION IF EXISTS public.resolve_fluor_id(p_token text);
DROP FUNCTION IF EXISTS public.process_fish_alleles_upload(p_by text);
DROP FUNCTION IF EXISTS public.plates_bi_assign_code();
DROP FUNCTION IF EXISTS public.plate_code_next();
DROP FUNCTION IF EXISTS public.normalize_genotype(p text);
DROP FUNCTION IF EXISTS public.link_plasmid_to_fusion(p_plasmid_code text, p_fusion_name text);
DROP FUNCTION IF EXISTS public.jct_bi_norm();
DROP FUNCTION IF EXISTS public.jct_bi_assign_group();
DROP FUNCTION IF EXISTS public.ja_biu_enforce_scale_100();
DROP FUNCTION IF EXISTS public.fusions_set_code_before_insert();
DROP FUNCTION IF EXISTS public.ft_proteins_normalize_codes();
DROP FUNCTION IF EXISTS public.ensure_plasmid_fusions_from_list_strict(p_plasmid_code text, p_fusion_list text);
DROP FUNCTION IF EXISTS public.ensure_plasmid_fusions_from_list(p_plasmid_code text, p_fusion_list text);
DROP FUNCTION IF EXISTS public.ensure_ft_markers_from_transgene(p_ft_code text);
DROP FUNCTION IF EXISTS public.ensure_active_tank_for_fish(p_fish_code text);
DROP FUNCTION IF EXISTS public.digest(text, text);
DROP FUNCTION IF EXISTS public.crosses_bi_assign_code();
DROP FUNCTION IF EXISTS public.cross_run_code_next();
DROP FUNCTION IF EXISTS public.clutch_instances_bi_assign_fields();
DROP FUNCTION IF EXISTS public.clutch_instance_code_next();
DROP FUNCTION IF EXISTS public._norm(s text);
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: _norm(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._norm(s text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  SELECT regexp_replace(lower(coalesce(s,'')), '\s+', ' ', 'g')::text
$$;


--
-- Name: clutch_instance_code_next(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clutch_instance_code_next() RETURNS text
    LANGUAGE sql
    AS $$
  SELECT 'CI-'||to_char(now(),'YYYYMMDD')||'-'||lpad(nextval('public.seq_clutch_instance_code')::text, 6, '0');
$$;


--
-- Name: clutch_instances_bi_assign_fields(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clutch_instances_bi_assign_fields() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.clutch_instance_code IS NULL OR NEW.clutch_instance_code = '' THEN
    NEW.clutch_instance_code := public.clutch_instance_code_next();
  END IF;
  NEW.normalized_genotype := public.normalize_genotype(NEW.clutch_genotype_pretty);
  RETURN NEW;
END
$$;


--
-- Name: cross_run_code_next(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cross_run_code_next() RETURNS text
    LANGUAGE sql
    AS $$
  SELECT 'CR-'||to_char(now(),'YYYYMMDD')||'-'||lpad(nextval('public.seq_cross_run_code')::text, 6, '0');
$$;


--
-- Name: crosses_bi_assign_code(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.crosses_bi_assign_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.cross_run_code IS NULL OR NEW.cross_run_code = '' THEN
    NEW.cross_run_code := public.cross_run_code_next();
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: digest(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.digest(text, text) RETURNS bytea
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
  SELECT digest(convert_to($1,'UTF8'), $2)
$_$;


--
-- Name: ensure_active_tank_for_fish(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_active_tank_for_fish(p_fish_code text) RETURNS uuid
    LANGUAGE plpgsql
    AS $_$
DECLARE
  v_existing uuid;
  v_next_num int;
  v_new_id   uuid;
BEGIN
  IF p_fish_code IS NULL OR btrim(p_fish_code) = '' THEN
    RAISE EXCEPTION 'ensure_active_tank_for_fish(): p_fish_code is required';
  END IF;

  -- return an existing active tank for this fish_code if present (most-recent)
  SELECT t.id INTO v_existing
  FROM public.tanks t
  WHERE t.tank_code LIKE 'TANK('||p_fish_code||')#%' AND COALESCE(t.status,'active') = 'active'
  ORDER BY t.created_at DESC
  LIMIT 1;

  IF v_existing IS NOT NULL THEN
    RETURN v_existing;
  END IF;

  -- compute next available #N for this fish_code from existing tank_code
  SELECT COALESCE(MAX( (regexp_replace(tank_code, '^.*#([0-9]+).*$', '\1'))::int ), 0)
    INTO v_next_num
  FROM public.tanks
  WHERE tank_code LIKE 'TANK('||p_fish_code||')#%';

  v_next_num := v_next_num + 1;

  INSERT INTO public.tanks (tank_code, status)
  VALUES ('TANK('||p_fish_code||')#'||v_next_num::text, 'active')
  RETURNING id INTO v_new_id;

  RETURN v_new_id;
END
$_$;


--
-- Name: ensure_ft_markers_from_transgene(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_ft_markers_from_transgene(p_ft_code text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- ensure TF master (forward-only, no backfill)
  INSERT INTO public.treatments_fluorescent (ft_code, ft_text, created_by)
  VALUES (p_ft_code, ''::text, 'system')
  ON CONFLICT (ft_code) DO NOTHING;

  -- derive marker pairs from plasmid→fusion
  INSERT INTO public.ft_proteins (ft_code, fluor_code, tag_code)
  SELECT DISTINCT p_ft_code AS ft_code, fl.fluor_code, tg.tag_code
  FROM public.plasmids p
  LEFT JOIN public.join_plasmid_fusions jpf ON jpf.plasmid_id = p.id
  LEFT JOIN public.fusions f               ON f.id = jpf.fusion_id
  LEFT JOIN public.fluors  fl              ON fl.id = f.fluor_id
  LEFT JOIN public.tags    tg              ON tg.id = f.tag_id
  WHERE p.code = p_ft_code
    AND (fl.fluor_code IS NOT NULL OR tg.tag_code IS NOT NULL)
  ON CONFLICT DO NOTHING;
END;
$$;


--
-- Name: ensure_plasmid_fusions_from_list(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_plasmid_fusions_from_list(p_plasmid_code text, p_fusion_list text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_plasmid_id uuid;
  v_part text;
  v_fluor_id uuid;
  v_fusion_id uuid;
BEGIN
  SELECT id INTO v_plasmid_id FROM public.plasmids WHERE code=p_plasmid_code LIMIT 1;
  IF v_plasmid_id IS NULL THEN
    RETURN;
  END IF;

  FOR v_part IN SELECT trim(x) FROM regexp_split_to_table(COALESCE(p_fusion_list,''), '\|') AS x LOOP
    EXIT WHEN v_part IS NULL OR v_part='';

    -- resolve fluor id by code or name
    SELECT id INTO v_fluor_id FROM public.fluors
     WHERE fluor_code=v_part OR fluor_name=v_part
     LIMIT 1;

    IF v_fluor_id IS NOT NULL THEN
      -- reuse existing fusion if present
      SELECT id INTO v_fusion_id FROM public.fusions WHERE fluor_id=v_fluor_id LIMIT 1;
      IF v_fusion_id IS NULL THEN
        INSERT INTO public.fusions (fusion_name, fluor_id, tag_id)
        VALUES (v_part, v_fluor_id, NULL)
        ON CONFLICT (fluor_id) DO UPDATE SET fusion_name=EXCLUDED.fusion_name
        RETURNING id INTO v_fusion_id;
      END IF;
    ELSE
      -- no known fluor yet → create placeholder fusion (no markers yet)
      v_fusion_id := public.upsert_fusion_by_names(v_part, NULL, NULL);
    END IF;

    INSERT INTO public.join_plasmid_fusions (plasmid_id, fusion_id)
    VALUES (v_plasmid_id, v_fusion_id)
    ON CONFLICT DO NOTHING;
  END LOOP;
END;
$$;


--
-- Name: ensure_plasmid_fusions_from_list_strict(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_plasmid_fusions_from_list_strict(p_plasmid_code text, p_fusion_list text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_plasmid_id uuid; v_raw text; v_parts text[]; v_left text; v_right text;
  v_fluor_id uuid; v_tag_id uuid; v_fusion_id uuid;
BEGIN
  SELECT id INTO v_plasmid_id FROM public.plasmids WHERE code=p_plasmid_code LIMIT 1;
  IF v_plasmid_id IS NULL THEN
    RAISE EXCEPTION 'plasmid "%" not found', p_plasmid_code USING ERRCODE='foreign_key_violation';
  END IF;

  FOR v_raw IN SELECT trim(x) FROM regexp_split_to_table(COALESCE(p_fusion_list,''), '\|') AS x LOOP
    IF v_raw IS NULL OR v_raw='' THEN CONTINUE; END IF;

    v_parts := regexp_split_to_array(v_raw, '[:/@+]+');
    IF array_length(v_parts,1) IS NULL THEN CONTINUE; END IF;

    IF array_length(v_parts,1)=1 THEN
      v_fluor_id := public.resolve_fluor_id(v_parts[1]);
      IF v_fluor_id IS NULL THEN
        RAISE EXCEPTION 'Unknown fluor "%". Add to public.fluors or fix CSV.', v_parts[1]
          USING ERRCODE='invalid_parameter_value';
      END IF;
      v_tag_id := NULL;
    ELSE
      v_left  := v_parts[1]; v_right := v_parts[array_length(v_parts,1)];
      v_fluor_id := public.resolve_fluor_id(v_right); v_tag_id := public.resolve_tag_id(v_left);
      IF v_fluor_id IS NULL THEN
        v_fluor_id := public.resolve_fluor_id(v_left);
        IF v_fluor_id IS NULL THEN
          RAISE EXCEPTION 'Unknown fluor in token "%". Add to public.fluors or fix CSV.', v_raw
            USING ERRCODE='invalid_parameter_value';
        END IF;
        IF v_right IS NOT NULL AND trim(v_right)<>'' THEN
          v_tag_id := public.resolve_tag_id(v_right);
          IF v_tag_id IS NULL THEN
            RAISE EXCEPTION 'Unknown tag "%". Add to public.tags or fix CSV.', v_right
              USING ERRCODE='invalid_parameter_value';
          END IF;
        ELSE
          v_tag_id := NULL;
        END IF;
      ELSE
        IF v_left IS NOT NULL AND trim(v_left)<>'' AND v_tag_id IS NULL THEN
          RAISE EXCEPTION 'Unknown tag "%". Add to public.tags or fix CSV.', v_left
            USING ERRCODE='invalid_parameter_value';
        END IF;
      END IF;
    END IF;

    INSERT INTO public.fusions (fusion_name, fluor_id, tag_id)
    VALUES (v_raw, v_fluor_id, v_tag_id)
    ON CONFLICT (fluor_id, COALESCE(tag_id,'00000000-0000-0000-0000-000000000000'::uuid))
    DO UPDATE SET fusion_name = EXCLUDED.fusion_name
    RETURNING id INTO v_fusion_id;

    INSERT INTO public.join_plasmid_fusions (plasmid_id, fusion_id)
    VALUES (v_plasmid_id, v_fusion_id)
    ON CONFLICT DO NOTHING;
  END LOOP;
END;
$$;


--
-- Name: ft_proteins_normalize_codes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ft_proteins_normalize_codes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_fluor text;
  v_tag   text;
BEGIN
  IF NEW.fluor_code IS NOT NULL AND NEW.fluor_code <> '' THEN
    SELECT f.fluor_code INTO v_fluor
    FROM public.fluors f
    WHERE lower(f.fluor_code)=lower(NEW.fluor_code)
       OR lower(COALESCE(f.fluor_name,''))=lower(NEW.fluor_code)
    LIMIT 1;
    IF v_fluor IS NOT NULL THEN
      NEW.fluor_code := v_fluor;
    ELSE
      NEW.fluor_code := upper(NEW.fluor_code);
    END IF;
  END IF;

  IF NEW.tag_code IS NOT NULL AND NEW.tag_code <> '' THEN
    SELECT t.tag_code INTO v_tag
    FROM public.tags t
    WHERE lower(t.tag_code)=lower(NEW.tag_code)
       OR lower(COALESCE(t.tag_name,''))=lower(NEW.tag_code)
    LIMIT 1;
    IF v_tag IS NOT NULL THEN
      NEW.tag_code := v_tag;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: fusions_set_code_before_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fusions_set_code_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.fusion_code IS NULL OR NEW.fusion_code = '' THEN
    NEW.fusion_code := public.slugify_code(NEW.fusion_name);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: ja_biu_enforce_scale_100(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ja_biu_enforce_scale_100() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_kind text;
BEGIN
  -- Only enforce for our 4 kinds
  SELECT kind_code INTO v_kind
  FROM public.annotations
  WHERE id = NEW.annotation_id
  LIMIT 1;

  IF v_kind IN ('red_intensity','green_intensity','red_frequency','green_frequency') THEN
    IF NEW.value_num IS NULL THEN
      RETURN NEW;
    END IF;

    -- If someone submits 0..1, auto-scale to 1..100
    IF NEW.value_num >= 0 AND NEW.value_num <= 1 THEN
      NEW.value_num := NEW.value_num * 100.0;
    END IF;

    -- Clamp into 1..100 band (allow 0 only if specifically desired; here we normalize 0→1)
    IF NEW.value_num < 1 THEN
      NEW.value_num := 1;
    ELSIF NEW.value_num > 100 THEN
      NEW.value_num := 100;
    END IF;

    -- Optionally round to integer; comment out if you want decimals
    NEW.value_num := ROUND(NEW.value_num);
  END IF;

  RETURN NEW;
END
$$;


--
-- Name: jct_bi_assign_group(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jct_bi_assign_group() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_group_id uuid;
BEGIN
  IF NEW.treated_clutch_id IS NOT NULL THEN
    RETURN NEW;
  END IF;

  -- find existing default group for this clutch_instance
  SELECT id INTO v_group_id
  FROM public.treated_clutches
  WHERE clutch_instance_id = NEW.clutch_instance_id
  ORDER BY created_at ASC
  LIMIT 1;

  IF v_group_id IS NULL THEN
    INSERT INTO public.treated_clutches (clutch_instance_id, label, created_by)
    VALUES (NEW.clutch_instance_id, 'default', COALESCE(NEW.created_by,'')) 
    RETURNING id INTO v_group_id;
  END IF;

  NEW.treated_clutch_id := v_group_id;
  RETURN NEW;
END
$$;


--
-- Name: jct_bi_norm(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jct_bi_norm() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.treatment_type_norm := public._norm(NEW.treatment_type);
  NEW.treatment_code_norm := public._norm(NEW.treatment_code);
  RETURN NEW;
END
$$;


--
-- Name: link_plasmid_to_fusion(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.link_plasmid_to_fusion(p_plasmid_code text, p_fusion_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  parts text[];
  p1 text;
  p2 text;
  v_fluor_id uuid;
  v_tag_id   uuid;
  v_plasmid_id uuid;
  v_fusion_id  uuid;
  v_fluor_name text;
  v_tag_name   text;
  v_fusion_code text;
BEGIN
  IF p_plasmid_code IS NULL OR btrim(p_plasmid_code) = '' THEN
    RAISE EXCEPTION 'plasmid_code is required';
  END IF;
  IF p_fusion_name IS NULL OR btrim(p_fusion_name) = '' THEN
    RAISE EXCEPTION 'fusion_name is required (expected "tag::fluor" or "fluor::tag") for plasmid %', p_plasmid_code;
  END IF;

  parts := regexp_split_to_array(btrim(p_fusion_name), '\s*::\s*');
  IF array_length(parts,1) <> 2 THEN
    RAISE EXCEPTION 'fusion_name must be exactly two parts separated by "::" (got: %)', p_fusion_name;
  END IF;

  p1 := btrim(parts[1]);
  p2 := btrim(parts[2]);

  SELECT id, fluor_name INTO v_fluor_id, v_fluor_name
  FROM public.fluors
  WHERE lower(fluor_name)=lower(p1) OR lower(coalesce(fluor_code,''))=lower(p1)
  LIMIT 1;

  SELECT id, tag_name INTO v_tag_id, v_tag_name
  FROM public.tags
  WHERE lower(tag_name)=lower(p2) OR lower(coalesce(tag_code,''))=lower(p2)
  LIMIT 1;

  IF v_fluor_id IS NULL OR v_tag_id IS NULL THEN
    -- try the opposite order
    SELECT id, fluor_name INTO v_fluor_id, v_fluor_name
    FROM public.fluors
    WHERE lower(fluor_name)=lower(p2) OR lower(coalesce(fluor_code,''))=lower(p2)
    LIMIT 1;

    SELECT id, tag_name INTO v_tag_id, v_tag_name
    FROM public.tags
    WHERE lower(tag_name)=lower(p1) OR lower(coalesce(tag_code,''))=lower(p1)
    LIMIT 1;
  END IF;

  IF v_fluor_id IS NULL OR v_tag_id IS NULL THEN
    RAISE EXCEPTION 'could not resolve fusion_name % to a fluor and tag (plasmid %)', p_fusion_name, p_plasmid_code;
  END IF;

  SELECT id INTO v_plasmid_id FROM public.plasmids WHERE code = p_plasmid_code LIMIT 1;
  IF v_plasmid_id IS NULL THEN
    RAISE EXCEPTION 'unknown plasmid_code: %', p_plasmid_code;
  END IF;

  v_fusion_code := replace(lower(v_fluor_name), ' ', '') || '-' || replace(lower(v_tag_name),' ',''); -- stable code
  INSERT INTO public.fusions (fusion_code, fusion_name, fluor_id, tag_id)
  VALUES (v_fusion_code, v_fluor_name || '::' || v_tag_name, v_fluor_id, v_tag_id)
  ON CONFLICT (fusion_code) DO UPDATE
    SET fluor_id = EXCLUDED.fluor_id,
        tag_id   = EXCLUDED.tag_id
  RETURNING id INTO v_fusion_id;

  INSERT INTO public.join_plasmid_fusions(plasmid_id, fusion_id)
  VALUES (v_plasmid_id, v_fusion_id)
  ON CONFLICT DO NOTHING;
END;
$$;


--
-- Name: normalize_genotype(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.normalize_genotype(p text) RETURNS text
    LANGUAGE sql
    AS $$
  SELECT regexp_replace(lower(coalesce(p,'')), '[^a-z0-9]+', '-', 'g');
$$;


--
-- Name: plate_code_next(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.plate_code_next() RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  v_day   text;   -- YYYYMMDD
  v_next  int;
BEGIN
  v_day := to_char(now(), 'YYYYMMDD');

  -- Prevent concurrent callers from generating the same number for this day
  PERFORM pg_advisory_xact_lock( hashtext('plate_code:' || v_day) );

  -- Compute the next daily number by scanning existing codes for this day
  SELECT COALESCE(
           MAX( (regexp_match(plate_code, '-([0-9]{3})$'))[1]::int ),
           0
         )
    INTO v_next
  FROM public.plates
  WHERE plate_code LIKE 'PLT-' || v_day || '-%';

  IF v_next >= 100 THEN
    RAISE EXCEPTION 'Daily plate-code limit (100) reached for %', v_day
      USING ERRCODE = 'check_violation';
  END IF;

  v_next := v_next + 1;

  RETURN 'PLT-' || v_day || '-' || lpad(v_next::text, 3, '0');
END
$_$;


--
-- Name: plates_bi_assign_code(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.plates_bi_assign_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.plate_code IS NULL OR NEW.plate_code = '' THEN
    NEW.plate_code := 'PLT-'||to_char(now(),'YYYYMMDD')||'-'||lpad(nextval('public.seq_plate_code')::text, 4, '0');
  END IF;
  IF NEW.created_at IS NULL THEN
    NEW.created_at := now();
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: process_fish_alleles_upload(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.process_fish_alleles_upload(p_by text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  r record;
  v_fish_id uuid;
  v_up  record;
  v_zyg text;
BEGIN
  FOR r IN
    SELECT
      btrim(NULLIF(fish_code,''))           AS fish_code,
      btrim(NULLIF(transgene_base_code,'')) AS base_code,
      NULLIF(allele_nickname,'')            AS allele_nick_raw,
      NULLIF(zygosity,'')                   AS zyg_raw
    FROM raw.fish_alleles_upload
  LOOP
    IF r.fish_code IS NULL OR r.base_code IS NULL THEN
      CONTINUE;
    END IF;

    -- resolve fish_id from fish_code
    SELECT id INTO v_fish_id
    FROM public.fish
    WHERE fish_code = r.fish_code
    LIMIT 1;

    IF v_fish_id IS NULL THEN
      CONTINUE;
    END IF;

    -- normalize zygosity to het/hom/unk
    v_zyg := CASE
               WHEN r.zyg_raw IS NULL THEN NULL
               WHEN lower(btrim(r.zyg_raw)) IN ('het','hetero','heterozygous','h') THEN 'het'
               WHEN lower(btrim(r.zyg_raw)) IN ('hom','homo','homozygous') THEN 'hom'
               WHEN lower(btrim(r.zyg_raw)) IN ('unk','unknown','?','na','n/a','none','') THEN 'unk'
               ELSE 'unk'
             END;

    -- upsert allele (nickname kept as string; blank → defaults to guN)
    SELECT * INTO v_up
    FROM public.upsert_transgene_allele(r.base_code, r.allele_nick_raw);

    -- link fish → allele (upsert zygosity)
    INSERT INTO public.join_fish_transgene_alleles (fish_id, transgene_base_code, allele_number, zygosity)
    VALUES (v_fish_id, v_up.transgene_base_code, v_up.allele_number, v_zyg)
    ON CONFLICT (fish_id, transgene_base_code, allele_number) DO UPDATE
      SET zygosity = COALESCE(EXCLUDED.zygosity, public.join_fish_transgene_alleles.zygosity);
  END LOOP;
END
$$;


--
-- Name: resolve_fluor_id(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_fluor_id(p_token text) RETURNS uuid
    LANGUAGE sql STABLE
    AS $_$
  SELECT id
  FROM public.fluors f
  WHERE lower(f.fluor_code)=lower($1)
     OR lower(COALESCE(f.fluor_name,''))=lower($1)
     OR (
          f.alt_names IS NOT NULL AND (
            (pg_typeof(f.alt_names)::text='text[]'
             AND EXISTS (SELECT 1 FROM unnest(f.alt_names) a WHERE lower(a)=lower($1)))
            OR
            (pg_typeof(f.alt_names)::text<>'text[]'
             AND lower(f.alt_names::text)=lower($1))
          )
        )
  ORDER BY id
  LIMIT 1;
$_$;


--
-- Name: resolve_tag_id(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_tag_id(p_token text) RETURNS uuid
    LANGUAGE sql STABLE
    AS $_$
  SELECT id
  FROM public.tags t
  WHERE lower(t.tag_code)=lower($1)
     OR lower(COALESCE(t.tag_name,''))=lower($1)
  ORDER BY id
  LIMIT 1;
$_$;


--
-- Name: row_letter(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.row_letter(p_row integer) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT chr(64 + GREATEST(1, LEAST(26, p_row)))
$$;


--
-- Name: slugify_code(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slugify_code(p text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT CASE
           WHEN s <> '' THEN s
           ELSE 'fusion_'||substr(md5(coalesce(p,'')),1,8)
         END
  FROM (SELECT trim(both '_' FROM lower(regexp_replace(coalesce(p,''), '[^a-zA-Z0-9]+', '_', 'g')))) t(s);
$$;


--
-- Name: tank_pair_code_next(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tank_pair_code_next() RETURNS text
    LANGUAGE sql
    AS $$
  SELECT 'TP-'||to_char(now(),'YYYYMMDD')||'-'||lpad(nextval('public.seq_tank_pair_code')::text, 6, '0');
$$;


--
-- Name: tank_pairs_bi_assign_code(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tank_pairs_bi_assign_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.tank_pair_code IS NULL OR NEW.tank_pair_code = '' THEN
    NEW.tank_pair_code := public.tank_pair_code_next();
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: tanks_bi_set_defaults(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tanks_bi_set_defaults() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.created_at IS NULL THEN NEW.created_at := now(); END IF;
  RETURN NEW;
END
$$;


--
-- Name: to_base36(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.to_base36(n bigint) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  chars text := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  result text := '';
  q bigint := n;
BEGIN
  IF q <= 0 THEN
    RETURN '0';
  END IF;
  WHILE q > 0 LOOP
    result := substr(chars, (q % 36) + 1, 1) || result;
    q := q / 36;
  END LOOP;
  RETURN result;
END;
$$;


--
-- Name: treated_clutch_code_next(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.treated_clutch_code_next() RETURNS text
    LANGUAGE sql
    AS $$
  SELECT 'TCI-'||to_char(now(),'YYYYMMDD')||'-'||lpad(nextval('public.seq_treated_clutch_code')::text, 6, '0');
$$;


--
-- Name: treated_clutches_ai_baseline(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.treated_clutches_ai_baseline() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO public.treated_clutches (clutch_instance_id, treated_clutch_code, created_by, created_at)
  VALUES (
    NEW.id,
    'T('||NEW.clutch_instance_code||')-0',
    COALESCE(current_setting('app.user', true), 'system'),
    COALESCE(NEW.created_at, now())
  )
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END
$$;


--
-- Name: treated_clutches_bi_assign_code(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.treated_clutches_bi_assign_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.treated_clutch_code IS NULL OR NEW.treated_clutch_code = '' THEN
    NEW.treated_clutch_code := public.treated_clutch_code_next();
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: trg_set_fish_code_base36(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_set_fish_code_base36() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.fish_code IS NULL OR btrim(NEW.fish_code) = '' THEN
    NEW.fish_code := 'FSH-' || lpad(upper(public.to_base36(nextval('public.seq_fish_code'))), 8, '0');
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_set_fish_code_from_uuid_base36_8(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_set_fish_code_from_uuid_base36_8() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
  code text := NULLIF(btrim(NEW.fish_code), '');
BEGIN
  IF NEW.id IS NULL THEN
    NEW.id := gen_random_uuid();
  END IF;

  -- Set if missing OR looks decimal (FSH-<digits>)
  IF code IS NULL OR code ~* '^FSH-\d+$' THEN
    NEW.fish_code := 'FSH-' || public.uuid_to_base36_8(NEW.id);
  END IF;

  RETURN NEW;
END
$_$;


--
-- Name: upsert_fish_by_identity(text, text, date, text, text, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upsert_fish_by_identity(p_seed_batch_id text, p_identity_key text, p_dob date, p_name_human text, p_bg text, p_nick text, p_stage text, p_desc text, p_notes text, p_by text) RETURNS TABLE(id uuid, fish_id uuid, fish_code text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_key  text;
  v_hash text;
  v_id   uuid;
  v_code text;
BEGIN
  v_key  := COALESCE(p_identity_key,'');
  v_hash := encode(digest(v_key,'sha256'), 'hex');

  SELECT f.id, f.fish_code
    INTO v_id, v_code
  FROM public.fish f
  WHERE f.identity_key = v_key
     OR f.identity_hash = v_hash
  LIMIT 1;

  IF v_id IS NOT NULL THEN
    id := v_id; fish_id := v_id; fish_code := v_code;
    RETURN NEXT; RETURN;
  END IF;

  v_code := 'FSH-'||lpad(nextval('public.seq_fish_code')::text, 8, '0');

  INSERT INTO public.fish (
    id, fish_code, nickname, dob,
    genetic_background, line_building_stage,
    identity_key, identity_hash, created_at
  )
  VALUES (
    gen_random_uuid(),
    v_code,
    NULLIF(p_nick,''),
    p_dob,
    NULLIF(p_bg,''),
    NULLIF(p_stage,''),
    v_key,
    v_hash,
    now()
  )
  RETURNING public.fish.id, public.fish.fish_code INTO v_id, v_code;

  id := v_id; fish_id := v_id; fish_code := v_code;
  RETURN NEXT;
END $$;


--
-- Name: upsert_fusion_by_names(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upsert_fusion_by_names(p_fusion_name text, p_fluor text, p_tag text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_fluor_id  uuid;
  v_tag_id    uuid;
  v_fusion_id uuid;
BEGIN
  SELECT id INTO v_fluor_id FROM public.fluors
   WHERE fluor_code=p_fluor OR fluor_name=p_fluor LIMIT 1;

  IF p_tag IS NOT NULL AND NULLIF(p_tag,'') IS NOT NULL THEN
    SELECT id INTO v_tag_id FROM public.tags
     WHERE tag_code=p_tag OR tag_name=p_tag LIMIT 1;
  END IF;

  -- If a fusion already exists for this fluor, reuse it (avoid uq_fusions_fluor_only)
  IF v_fluor_id IS NOT NULL THEN
    SELECT id INTO v_fusion_id FROM public.fusions WHERE fluor_id=v_fluor_id LIMIT 1;
    IF v_fusion_id IS NOT NULL THEN
      RETURN v_fusion_id;
    END IF;
  END IF;

  -- Otherwise insert a new fusion; trigger sets fusion_code
  INSERT INTO public.fusions (fusion_name, fluor_id, tag_id)
  VALUES (p_fusion_name, v_fluor_id, v_tag_id)
  ON CONFLICT (fluor_id) DO UPDATE
    SET fusion_name = EXCLUDED.fusion_name
  RETURNING id INTO v_fusion_id;

  RETURN v_fusion_id;
END;
$$;


--
-- Name: upsert_transgene_allele(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upsert_transgene_allele(p_transgene_base_code text, p_allele_nickname text) RETURNS TABLE(out_base text, out_number bigint, out_name text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_base text := btrim(p_transgene_base_code);
  v_nick text := NULLIF(btrim(p_allele_nickname), '');
  v_num  bigint;
  v_name text;
BEGIN
  IF v_base IS NULL OR v_base = '' THEN
    RETURN;
  END IF;

  -- ensure a transgene row exists (only base column)
  INSERT INTO public.transgenes (transgene_base_code)
  VALUES (v_base)
  ON CONFLICT ON CONSTRAINT transgenes_pkey DO NOTHING;

  -- try reuse by nickname (within same base), case-insensitive
  IF v_nick IS NOT NULL THEN
    SELECT ta.allele_number, ta.allele_name
      INTO v_num, v_name
    FROM public.transgene_alleles ta
    WHERE ta.transgene_base_code = v_base
      AND lower(btrim(ta.allele_nickname)) = lower(btrim(v_nick))
    LIMIT 1;

    IF v_num IS NOT NULL THEN
      out_base := v_base; out_number := v_num; out_name := v_name;
      RETURN NEXT; RETURN;
    END IF;
  END IF;

  -- mint new global number (prefer sequence; fallback to MAX+1)
  BEGIN
    v_num := nextval('public.seq_global_allele_number');
  EXCEPTION
    WHEN undefined_table OR undefined_object THEN
      SELECT COALESCE(MAX(allele_number), 0) + 1 INTO v_num FROM public.transgene_alleles;
  END;

  v_name := 'gu' || v_num::text;

  INSERT INTO public.transgene_alleles (
    transgene_base_code, allele_number, allele_name, allele_nickname
  ) VALUES (
    v_base, v_num, v_name, COALESCE(v_nick, v_name)
  )
  ON CONFLICT ON CONSTRAINT transgene_alleles_pkey DO NOTHING;

  out_base := v_base; out_number := v_num; out_name := v_name;
  RETURN NEXT;
END
$$;


--
-- Name: uuid_to_base36_8(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.uuid_to_base36_8(p uuid) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  b bytea := decode(replace(p::text, '-', ''), 'hex');  -- 16 bytes
  m bigint := 36^8;                                     -- 2,821,109,907,456
  rem bigint := 0;
  i int;
  v int;
  chars constant text := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  out text := '';
BEGIN
  FOR i IN 0..15 LOOP
    v := get_byte(b, i);
    rem := (rem * 256 + v)::bigint % m;
  END LOOP;

  IF rem = 0 THEN
    out := '0';
  ELSE
    WHILE rem > 0 LOOP
      out := substr(chars, (rem % 36)::int + 1, 1) || out;
      rem := rem / 36;
    END LOOP;
  END IF;

  RETURN lpad(upper(out), 8, '0');
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: annotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annotations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    kind_code text NOT NULL,
    label text,
    description text
);


--
-- Name: clutch_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clutch_instances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cross_instance_id uuid NOT NULL,
    tank_pair_code text NOT NULL,
    clutch_instance_code text NOT NULL,
    clutch_genotype_pretty text NOT NULL,
    normalized_genotype text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: crosses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crosses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tank_pair_code text NOT NULL,
    cross_date date NOT NULL,
    cross_run_code text NOT NULL,
    created_by text,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dyes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dyes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dye_code text NOT NULL,
    dye_name text,
    excitation_nm smallint,
    emission_nm smallint,
    alt_names text[],
    notes text,
    localization text
);


--
-- Name: fish; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fish (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    fish_code text NOT NULL,
    nickname text,
    dob date,
    genetic_background text,
    line_building_stage text,
    identity_key text,
    identity_hash text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_fish_code_format CHECK ((fish_code ~* '^FSH-[0-9A-Z]{8}$'::text))
);


--
-- Name: fluors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fluors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    fluor_code text NOT NULL,
    fluor_name text,
    excitation_nm smallint,
    emission_nm smallint,
    alt_names text[],
    notes text
);


--
-- Name: ft_dyes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ft_dyes (
    ft_code text NOT NULL,
    dye_code text NOT NULL
);


--
-- Name: ft_proteins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ft_proteins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ft_code text NOT NULL,
    fluor_code text NOT NULL,
    tag_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fusions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    fusion_code text NOT NULL,
    fusion_name text,
    fluor_id uuid,
    tag_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    dye_id uuid
);


--
-- Name: join_annotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_annotations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_type text NOT NULL,
    target_id uuid NOT NULL,
    annotation_id uuid NOT NULL,
    value_num numeric,
    value_text text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: join_clutch_treatments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_clutch_treatments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clutch_instance_id uuid NOT NULL,
    treatment_type text NOT NULL,
    treatment_code text NOT NULL,
    treatment_name text,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    treatment_type_norm text NOT NULL,
    treatment_code_norm text NOT NULL,
    treated_clutch_id uuid
);


--
-- Name: join_dyes_fluorescent_treatments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_dyes_fluorescent_treatments (
    ft_code text NOT NULL,
    dye_code text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: join_fish_fluorescent_treatments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_fish_fluorescent_treatments (
    fish_id uuid NOT NULL,
    ft_code text NOT NULL,
    allele_number text,
    zygosity text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: join_fish_transgene_alleles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_fish_transgene_alleles (
    fish_id uuid NOT NULL,
    transgene_base_code text NOT NULL,
    allele_number integer NOT NULL,
    zygosity text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: join_plasmid_fusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_plasmid_fusions (
    plasmid_id uuid NOT NULL,
    fusion_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plasmids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plasmids (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    nickname text,
    resistance text,
    supports_invitro_rna boolean DEFAULT false NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plate_formats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plate_formats (
    code text NOT NULL,
    name text,
    n_rows integer NOT NULL,
    n_cols integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plate_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plate_slots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plate_id uuid NOT NULL,
    row_idx integer NOT NULL,
    col_idx integer NOT NULL,
    treated_clutch_id uuid,
    fish_code text,
    orientation text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seq_plate_code; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_plate_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plate_code text DEFAULT ((('PLT-'::text || to_char(now(), 'YYYYMMDD'::text)) || '-'::text) || lpad((nextval('public.seq_plate_code'::regclass))::text, 4, '0'::text)),
    format_code text NOT NULL,
    plate_name text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seq_clutch_instance_code; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_clutch_instance_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_cross_run_code; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_cross_run_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_fish_code; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_fish_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_global_allele_number; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_global_allele_number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_tank_pair_code; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_tank_pair_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_treated_clutch_code; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_treated_clutch_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tag_code text NOT NULL,
    tag_name text,
    localization text,
    note text,
    citation_link text
);


--
-- Name: tank_pairs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tank_pairs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tank_pair_code text NOT NULL,
    mother_tank_id uuid,
    father_tank_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tanks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tanks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tank_code text NOT NULL,
    location_id uuid,
    status text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transgene_alleles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transgene_alleles (
    transgene_base_code text NOT NULL,
    allele_number integer NOT NULL,
    allele_nickname text,
    allele_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transgenes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transgenes (
    transgene_base_code text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: treated_clutches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treated_clutches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    treated_clutch_code text NOT NULL,
    clutch_instance_id uuid NOT NULL,
    label text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: treatments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatments (
    treat_code text NOT NULL,
    kind text NOT NULL,
    treat_text text DEFAULT ''::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: treatments_chemical; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatments_chemical (
    ct_code text NOT NULL,
    ct_text text DEFAULT ''::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: treatments_fluorescent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatments_fluorescent (
    ft_code text NOT NULL,
    ft_text text DEFAULT ''::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: treatments_physical; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatments_physical (
    pt_code text NOT NULL,
    pt_text text DEFAULT ''::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: v_annotations_latest; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_annotations_latest AS
 WITH ranked AS (
         SELECT ja.target_type,
            ja.target_id,
            a.kind_code,
            ja.value_num,
            ja.value_text,
            ja.created_by,
            ja.created_at,
            row_number() OVER (PARTITION BY ja.target_type, ja.target_id, a.kind_code ORDER BY ja.created_at DESC, ja.id DESC) AS rn
           FROM (public.join_annotations ja
             JOIN public.annotations a ON ((a.id = ja.annotation_id)))
        )
 SELECT target_type,
    target_id,
    kind_code,
    value_num,
    value_text,
    created_by,
    created_at,
    rn
   FROM ranked
  WHERE (rn = 1);


--
-- Name: v_annotations_latest_group; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_annotations_latest_group AS
 WITH ranked AS (
         SELECT j.target_type,
            j.target_id,
            a.kind_code,
            COALESCE(j.value_num, (0)::numeric) AS value_num,
            COALESCE(j.value_text, ''::text) AS value_text,
            j.created_at,
            row_number() OVER (PARTITION BY j.target_type, j.target_id, a.kind_code ORDER BY j.created_at DESC NULLS LAST, j.id DESC) AS rn
           FROM (public.join_annotations j
             JOIN public.annotations a ON ((a.id = j.annotation_id)))
          WHERE (j.target_type = ANY (ARRAY['clutch'::text, 'treated_clutch'::text]))
        )
 SELECT target_type,
    target_id,
    kind_code,
    value_num,
    value_text,
    created_at
   FROM ranked
  WHERE (rn = 1);


--
-- Name: v_clutch_instances; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_clutch_instances AS
 WITH tx AS (
         SELECT ci_1.clutch_instance_code AS clutch_code,
            (count(*))::integer AS treatments_count_effective,
            string_agg(DISTINCT jct.treatment_code, ' + '::text ORDER BY jct.treatment_code) AS clutch_treatments_codes,
            string_agg(DISTINCT COALESCE(NULLIF(jct.treatment_name, ''::text), jct.treatment_code), ' + '::text ORDER BY COALESCE(NULLIF(jct.treatment_name, ''::text), jct.treatment_code)) AS clutch_treatments_names
           FROM (public.clutch_instances ci_1
             LEFT JOIN public.join_clutch_treatments jct ON ((jct.clutch_instance_id = ci_1.id)))
          GROUP BY ci_1.clutch_instance_code
        )
 SELECT ci.clutch_instance_code AS clutch_code,
    cr.cross_date AS clutch_birthday,
    cr.cross_run_code AS cross_name_pretty,
    ci.clutch_instance_code AS clutch_name,
    regexp_replace(COALESCE(ci.clutch_genotype_pretty, ''::text), '\s*[×x]\s*'::text, ' ; '::text, 'g'::text) AS clutch_genotype_pretty,
    ''::text AS clutch_strain_pretty,
    COALESCE(tx.treatments_count_effective, 0) AS treatments_count_effective,
    COALESCE(tx.clutch_treatments_names, ''::text) AS treatments_pretty_effective,
    COALESCE(tx.clutch_treatments_codes, ''::text) AS clutch_treatments_codes,
    COALESCE(tx.clutch_treatments_names, ''::text) AS clutch_treatments_names,
    ''::text AS clutch_treatments_fusions,
    ''::text AS clutch_genotype_fusions,
    ''::text AS clutch_lineage_pretty,
    ''::text AS clutch_lineage_fusions_pretty,
    ''::text AS clutch_lineage_full_fusions_pretty,
        CASE
            WHEN (COALESCE(tx.clutch_treatments_codes, ''::text) <> ''::text) THEN ((tx.clutch_treatments_codes || ' > '::text) || regexp_replace(COALESCE(ci.clutch_genotype_pretty, ''::text), '\s*[×x]\s*'::text, ' ; '::text, 'g'::text))
            ELSE regexp_replace(COALESCE(ci.clutch_genotype_pretty, ''::text), '\s*[×x]\s*'::text, ' ; '::text, 'g'::text)
        END AS treatment_genotype,
    COALESCE(cr.created_by, ''::text) AS created_by_instance,
    COALESCE(ci.created_at, cr.created_at) AS created_at_instance
   FROM ((public.clutch_instances ci
     JOIN public.crosses cr ON ((cr.id = ci.cross_instance_id)))
     LEFT JOIN tx ON ((tx.clutch_code = ci.clutch_instance_code)));


--
-- Name: v_dyes_lu; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_dyes_lu AS
 SELECT dye_code AS code,
    COALESCE(dye_name, dye_code) AS label
   FROM public.dyes;


--
-- Name: v_fish_fluorescent_markers; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fish_fluorescent_markers AS
 SELECT f.fish_code,
    array_agg(DISTINCT jft.ft_code ORDER BY jft.ft_code) AS markers,
    array_agg(DISTINCT ftpr.fluor_code ORDER BY ftpr.fluor_code) AS fluors,
    array_agg(DISTINCT ftpr.tag_code ORDER BY ftpr.tag_code) AS tags,
    array_agg(DISTINCT ftd.dye_code ORDER BY ftd.dye_code) AS dyes
   FROM (((public.fish f
     LEFT JOIN public.join_fish_fluorescent_treatments jft ON ((jft.fish_id = f.id)))
     LEFT JOIN public.ft_proteins ftpr ON ((ftpr.ft_code = jft.ft_code)))
     LEFT JOIN public.ft_dyes ftd ON ((ftd.ft_code = jft.ft_code)))
  GROUP BY f.fish_code;


--
-- Name: v_fish_genotype_rollup_by_ids; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fish_genotype_rollup_by_ids AS
 WITH jt AS (
         SELECT j.fish_id,
            ga.transgene_base_code,
            ga.allele_number,
            COALESCE(NULLIF(j.zygosity, ''::text), 'unk'::text) AS zygosity,
            NULLIF(ga.allele_nickname, ''::text) AS allele_nickname
           FROM (public.join_fish_transgene_alleles j
             JOIN public.transgene_alleles ga ON (((ga.transgene_base_code = j.transgene_base_code) AND (ga.allele_number = j.allele_number))))
        )
 SELECT fish_id,
    (count(*))::integer AS allele_count,
    COALESCE(NULLIF(string_agg(DISTINCT ((transgene_base_code || ':'::text) || allele_number), ', '::text), ''::text), ''::text) AS allele_codes,
    COALESCE(NULLIF(string_agg(DISTINCT COALESCE(allele_nickname, ''::text), ', '::text), ''::text), ''::text) AS allele_nicknames,
    COALESCE(NULLIF(string_agg(DISTINCT transgene_base_code, ', '::text), ''::text), ''::text) AS transgenes,
    COALESCE(NULLIF(string_agg(DISTINCT (((transgene_base_code || ':'::text) || allele_number) ||
        CASE
            WHEN (zygosity IS NOT NULL) THEN ((' ('::text || zygosity) || ')'::text)
            ELSE ''::text
        END), ', '::text), ''::text), ''::text) AS genotype_rollup
   FROM jt
  GROUP BY fish_id;


--
-- Name: v_fish_main; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fish_main AS
 SELECT 'stub'::text AS fish_code;


--
-- Name: v_fish_marker_rollup_by_ids; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fish_marker_rollup_by_ids AS
 WITH j AS (
         SELECT f.id AS fish_id,
            jft.ft_code
           FROM (public.fish f
             LEFT JOIN public.join_fish_fluorescent_treatments jft ON ((jft.fish_id = f.id)))
        )
 SELECT fish_id,
    COALESCE(( SELECT (count(DISTINCT j.ft_code))::integer AS count
           FROM j
          WHERE (j.fish_id = x.fish_id)), 0) AS marker_count,
    ''::text AS fusion_rollup,
    COALESCE(( SELECT string_agg(DISTINCT p.fluor_code, ','::text ORDER BY p.fluor_code) AS string_agg
           FROM (j
             LEFT JOIN public.ft_proteins p ON ((p.ft_code = j.ft_code)))
          WHERE ((j.fish_id = x.fish_id) AND (p.fluor_code IS NOT NULL))), ''::text) AS fluor_rollup,
    COALESCE(( SELECT string_agg(DISTINCT p.tag_code, ','::text ORDER BY p.tag_code) AS string_agg
           FROM (j
             LEFT JOIN public.ft_proteins p ON ((p.ft_code = j.ft_code)))
          WHERE ((j.fish_id = x.fish_id) AND (p.tag_code IS NOT NULL))), ''::text) AS tag_rollup,
    COALESCE(( SELECT string_agg(DISTINCT d.dye_code, ','::text ORDER BY d.dye_code) AS string_agg
           FROM (j
             LEFT JOIN public.ft_dyes d ON ((d.ft_code = j.ft_code)))
          WHERE ((j.fish_id = x.fish_id) AND (d.dye_code IS NOT NULL))), ''::text) AS dye_rollup
   FROM ( SELECT fish.id AS fish_id
           FROM public.fish) x;


--
-- Name: v_fish_overview_id; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fish_overview_id AS
 SELECT f.fish_code,
    f.nickname,
    f.dob AS birthday,
    COALESCE(f.genetic_background, ''::text) AS genetic_background,
    COALESCE(f.line_building_stage, ''::text) AS line_building_stage,
    COALESCE(g.allele_count, 0) AS allele_count,
    COALESCE(g.allele_codes, ''::text) AS allele_codes,
    COALESCE(g.allele_nicknames, ''::text) AS allele_nicknames,
    COALESCE(g.transgenes, ''::text) AS transgenes,
    COALESCE(g.genotype_rollup, ''::text) AS genotype_rollup,
    COALESCE(m.fusion_rollup, ''::text) AS fusion_rollup,
    COALESCE(m.fluor_rollup, ''::text) AS fluor_rollup,
    COALESCE(m.tag_rollup, ''::text) AS tag_rollup,
    COALESCE(m.dye_rollup, ''::text) AS dye_rollup,
    f.created_at
   FROM ((public.fish f
     LEFT JOIN public.v_fish_genotype_rollup_by_ids g ON ((g.fish_id = f.id)))
     LEFT JOIN public.v_fish_marker_rollup_by_ids m ON ((m.fish_id = f.id)));


--
-- Name: VIEW v_fish_overview_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.v_fish_overview_id IS 'CANON: single PK-based fish overview';


--
-- Name: v_fish_unified; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fish_unified AS
 WITH markers AS (
         SELECT f_1.fish_code,
            (((ta.transgene_base_code || '('::text) || ta.allele_name) || ')'::text) AS marker_label
           FROM ((public.join_fish_transgene_alleles jf
             JOIN public.transgene_alleles ta ON (((ta.transgene_base_code = jf.transgene_base_code) AND (ta.allele_number = jf.allele_number))))
             JOIN public.fish f_1 ON ((f_1.id = jf.fish_id)))
          WHERE (NULLIF(ta.allele_name, ''::text) IS NOT NULL)
        ), gp AS (
         SELECT m.fish_code,
            string_agg(DISTINCT m.marker_label, ', '::text ORDER BY m.marker_label) AS genotype_pretty
           FROM markers m
          GROUP BY m.fish_code
        )
 SELECT f.fish_code,
    COALESCE(gp.genotype_pretty, ''::text) AS genotype_pretty
   FROM (public.fish f
     LEFT JOIN gp ON ((gp.fish_code = f.fish_code)));


--
-- Name: v_fluorescent_marker_rollup; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fluorescent_marker_rollup AS
 SELECT 'stub'::text AS fish_code;


--
-- Name: v_fluorescent_marker_rollup_by_base; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fluorescent_marker_rollup_by_base AS
 SELECT 'stub'::text AS fish_code;


--
-- Name: v_fluors_lu; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fluors_lu AS
 SELECT fluor_code AS code,
    COALESCE(fluor_name, fluor_code) AS label
   FROM public.fluors;


--
-- Name: v_tags_lu; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_tags_lu AS
 SELECT tag_code AS code,
    COALESCE(tag_name, tag_code) AS label
   FROM public.tags;


--
-- Name: v_fluorescent_treatment_markers; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fluorescent_treatment_markers AS
 SELECT pm.ft_code,
    'protein'::text AS marker_kind,
    pm.fluor_code,
    pm.tag_code,
    vf.label AS fluor_label,
    vt.label AS tag_label,
    NULL::text AS dye_code,
    NULL::text AS dye_label,
    pm.created_at
   FROM ((public.ft_proteins pm
     LEFT JOIN public.v_fluors_lu vf ON ((vf.code = pm.fluor_code)))
     LEFT JOIN public.v_tags_lu vt ON ((vt.code = pm.tag_code)))
UNION ALL
 SELECT d.ft_code,
    'dye'::text AS marker_kind,
    NULL::text AS fluor_code,
    NULL::text AS tag_code,
    NULL::text AS fluor_label,
    NULL::text AS tag_label,
    d.dye_code,
    vd.label AS dye_label,
    d.created_at
   FROM (public.join_dyes_fluorescent_treatments d
     LEFT JOIN public.v_dyes_lu vd ON ((vd.code = d.dye_code)));


--
-- Name: v_plasmids; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_plasmids AS
SELECT
    NULL::uuid AS id,
    NULL::text AS code,
    NULL::text AS name,
    NULL::text AS nickname,
    NULL::text AS resistance,
    NULL::boolean AS supports_invitro_rna,
    NULL::text AS notes,
    NULL::text AS created_by,
    NULL::timestamp with time zone AS created_at,
    NULL::text AS fluors,
    NULL::text AS tags,
    NULL::text AS fusions,
    NULL::text[] AS fluors_arr,
    NULL::text[] AS tags_arr,
    NULL::text[] AS fusions_arr;


--
-- Name: v_plasmids_rich; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_plasmids_rich AS
 WITH links AS (
         SELECT p_1.id AS plasmid_id,
            p_1.code AS plasmid_code,
            f.fusion_code,
            COALESCE(fl.fluor_name, fl.fluor_code, ''::text) AS fluor_name,
            COALESCE(tg.tag_name, tg.tag_code, ''::text) AS tag_name
           FROM ((((public.plasmids p_1
             LEFT JOIN public.join_plasmid_fusions j ON ((j.plasmid_id = p_1.id)))
             LEFT JOIN public.fusions f ON ((f.id = j.fusion_id)))
             LEFT JOIN public.fluors fl ON ((fl.id = f.fluor_id)))
             LEFT JOIN public.tags tg ON ((tg.id = f.tag_id)))
        ), agg AS (
         SELECT links.plasmid_id,
            links.plasmid_code,
            COALESCE(NULLIF(string_agg(DISTINCT links.fusion_code, ', '::text), ''::text), ''::text) AS fusion_names,
            COALESCE(NULLIF(string_agg(DISTINCT links.fluor_name, ', '::text), ''::text), ''::text) AS fluor_names,
            COALESCE(NULLIF(string_agg(DISTINCT links.tag_name, ', '::text), ''::text), ''::text) AS tag_names
           FROM links
          GROUP BY links.plasmid_id, links.plasmid_code
        )
 SELECT p.id AS plasmid_id,
    p.code AS plasmid_code,
    p.name AS plasmid_name,
    COALESCE(p.nickname, ''::text) AS nickname,
    COALESCE(a.fluor_names, ''::text) AS fluor_names,
    COALESCE(a.tag_names, ''::text) AS tag_names,
    COALESCE(a.fusion_names, ''::text) AS fusion_names,
    COALESCE(p.resistance, ''::text) AS resistance,
    p.supports_invitro_rna,
    p.notes,
    p.created_by,
    p.created_at
   FROM (public.plasmids p
     LEFT JOIN agg a ON ((a.plasmid_id = p.id)));


--
-- Name: v_plate_layout; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_plate_layout AS
 SELECT p.plate_code,
    COALESCE(p.plate_name, ''::text) AS plate_name,
    p.format_code,
    pf.n_rows,
    pf.n_cols,
    s.row_idx,
    s.col_idx,
    public.row_letter(s.row_idx) AS row_letter,
    (public.row_letter(s.row_idx) || lpad((s.col_idx)::text, 2, '0'::text)) AS well_label,
    s.treated_clutch_id,
    COALESCE(tc.treated_clutch_code, ''::text) AS treated_clutch_code,
    COALESCE(s.fish_code, ''::text) AS fish_code,
    COALESCE(s.orientation, ''::text) AS orientation,
    s.created_at
   FROM (((public.plate_slots s
     JOIN public.plates p ON ((p.id = s.plate_id)))
     JOIN public.plate_formats pf ON ((pf.code = p.format_code)))
     LEFT JOIN public.treated_clutches tc ON ((tc.id = s.treated_clutch_id)))
  ORDER BY p.plate_code, s.row_idx, s.col_idx;


--
-- Name: v_tanks; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_tanks AS
 SELECT id AS tank_uuid,
    tank_code,
    regexp_replace(tank_code, '^.*\(([^)]+)\).*$'::text, '\1'::text) AS fish_code,
    (NULLIF(regexp_replace(tank_code, '^.*#([0-9]+).*$'::text, '\1'::text), ''::text))::integer AS tank_num,
    status,
    created_at
   FROM public.tanks t;


--
-- Name: v_tank_pairs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_tank_pairs AS
 SELECT tp.tank_pair_code,
    vtm.fish_code AS mom_fish_code,
    vtm.tank_code AS mom_tank_code,
    COALESCE(vfm.genotype_pretty, ''::text) AS mom_genotype,
    vtf.fish_code AS dad_fish_code,
    vtf.tank_code AS dad_tank_code,
    COALESCE(vff.genotype_pretty, ''::text) AS dad_genotype,
    NULL::text AS status,
    NULL::text AS created_by,
    tp.created_at
   FROM ((((public.tank_pairs tp
     LEFT JOIN public.v_tanks vtm ON ((vtm.tank_uuid = tp.mother_tank_id)))
     LEFT JOIN public.v_tanks vtf ON ((vtf.tank_uuid = tp.father_tank_id)))
     LEFT JOIN public.v_fish_unified vfm ON ((vfm.fish_code = vtm.fish_code)))
     LEFT JOIN public.v_fish_unified vff ON ((vff.fish_code = vtf.fish_code)));


--
-- Name: v_treated_clutch_annotations_pivot; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_treated_clutch_annotations_pivot AS
 SELECT tg.id AS treated_clutch_id,
    tg.treated_clutch_code,
    max(
        CASE
            WHEN (g.kind_code = 'red_intensity'::text) THEN g.value_num
            ELSE NULL::numeric
        END) AS red_intensity,
    max(
        CASE
            WHEN (g.kind_code = 'green_intensity'::text) THEN g.value_num
            ELSE NULL::numeric
        END) AS green_intensity,
    max(
        CASE
            WHEN (g.kind_code = 'green_frequency'::text) THEN g.value_num
            ELSE NULL::numeric
        END) AS green_frequency,
    max(
        CASE
            WHEN (g.kind_code = 'red_frequency'::text) THEN g.value_num
            ELSE NULL::numeric
        END) AS red_frequency,
    max(
        CASE
            WHEN (g.kind_code = 'n_animals'::text) THEN g.value_num
            ELSE NULL::numeric
        END) AS n_animals,
    max(
        CASE
            WHEN (g.kind_code = 'notes'::text) THEN g.value_text
            ELSE NULL::text
        END) AS notes,
    max(g.created_at) AS annotations_last_at
   FROM (public.treated_clutches tg
     LEFT JOIN public.v_annotations_latest_group g ON (((g.target_type = 'treated_clutch'::text) AND (g.target_id = tg.id))))
  GROUP BY tg.id, tg.treated_clutch_code;


--
-- Name: v_treated_clutches; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_treated_clutches AS
 WITH tx AS (
         SELECT jct.treated_clutch_id,
            (count(*))::integer AS treatments_count,
            string_agg(DISTINCT jct.treatment_code, ' + '::text ORDER BY jct.treatment_code) AS treatments_codes,
            string_agg(DISTINCT COALESCE(NULLIF(jct.treatment_name, ''::text), jct.treatment_code), ' + '::text ORDER BY COALESCE(NULLIF(jct.treatment_name, ''::text), jct.treatment_code)) AS treatments_names
           FROM public.join_clutch_treatments jct
          GROUP BY jct.treated_clutch_id
        )
 SELECT tc.treated_clutch_code,
    tc.id AS treated_clutch_id,
    tc.created_at AS group_created_at,
    ci.clutch_instance_code AS clutch_code,
    cr.cross_run_code AS cross_name_pretty,
    cr.cross_date AS clutch_birthday,
    regexp_replace(COALESCE(ci.clutch_genotype_pretty, ''::text), '\s*[×x]\s*'::text, ' ; '::text, 'g'::text) AS clutch_genotype_pretty,
    COALESCE(tx.treatments_count, 0) AS treatments_count_group,
    COALESCE(tx.treatments_codes, ''::text) AS treatments_codes_group,
    COALESCE(tx.treatments_names, ''::text) AS treatments_names_group,
        CASE
            WHEN (COALESCE(tx.treatments_codes, ''::text) <> ''::text) THEN ((tx.treatments_codes || ' > '::text) || regexp_replace(COALESCE(ci.clutch_genotype_pretty, ''::text), '\s*[×x]\s*'::text, ' ; '::text, 'g'::text))
            ELSE regexp_replace(COALESCE(ci.clutch_genotype_pretty, ''::text), '\s*[×x]\s*'::text, ' ; '::text, 'g'::text)
        END AS treatment_genotype_group
   FROM (((public.treated_clutches tc
     JOIN public.clutch_instances ci ON ((ci.id = tc.clutch_instance_id)))
     JOIN public.crosses cr ON ((cr.id = ci.cross_instance_id)))
     LEFT JOIN tx ON ((tx.treated_clutch_id = tc.id)));


--
-- Name: v_treatments_catalog; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_treatments_catalog AS
 SELECT tf.ft_code AS code,
    'fluorescent'::text AS kind,
    COALESCE(tf.ft_text, ''::text) AS label,
    tf.created_by,
    tf.created_at,
    'treatments_fluorescent'::text AS source
   FROM public.treatments_fluorescent tf
UNION ALL
 SELECT tc.ct_code AS code,
    'chemical'::text AS kind,
    COALESCE(tc.ct_text, ''::text) AS label,
    tc.created_by,
    tc.created_at,
    'treatments_chemical'::text AS source
   FROM public.treatments_chemical tc
UNION ALL
 SELECT tp.pt_code AS code,
    'physical'::text AS kind,
    COALESCE(tp.pt_text, ''::text) AS label,
    tp.created_by,
    tp.created_at,
    'treatments_physical'::text AS source
   FROM public.treatments_physical tp
UNION ALL
 SELECT t.treat_code AS code,
    COALESCE(NULLIF(t.kind, ''::text), 'other'::text) AS kind,
    COALESCE(t.treat_text, ''::text) AS label,
    t.created_by,
    t.created_at,
    'treatments'::text AS source
   FROM public.treatments t;


--
-- Name: annotations annotations_kind_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_kind_code_key UNIQUE (kind_code);


--
-- Name: annotations annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_pkey PRIMARY KEY (id);


--
-- Name: clutch_instances clutch_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clutch_instances
    ADD CONSTRAINT clutch_instances_pkey PRIMARY KEY (id);


--
-- Name: crosses crosses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crosses
    ADD CONSTRAINT crosses_pkey PRIMARY KEY (id);


--
-- Name: dyes dyes_dye_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dyes
    ADD CONSTRAINT dyes_dye_code_key UNIQUE (dye_code);


--
-- Name: dyes dyes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dyes
    ADD CONSTRAINT dyes_pkey PRIMARY KEY (id);


--
-- Name: fish fish_fish_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fish
    ADD CONSTRAINT fish_fish_code_key UNIQUE (fish_code);


--
-- Name: fish fish_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fish
    ADD CONSTRAINT fish_pkey PRIMARY KEY (id);


--
-- Name: fluors fluors_fluor_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fluors
    ADD CONSTRAINT fluors_fluor_code_key UNIQUE (fluor_code);


--
-- Name: fluors fluors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fluors
    ADD CONSTRAINT fluors_pkey PRIMARY KEY (id);


--
-- Name: ft_dyes ft_dyes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_dyes
    ADD CONSTRAINT ft_dyes_pkey PRIMARY KEY (ft_code, dye_code);


--
-- Name: ft_proteins ft_proteins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_proteins
    ADD CONSTRAINT ft_proteins_pkey PRIMARY KEY (id);


--
-- Name: fusions fusions_fusion_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusions
    ADD CONSTRAINT fusions_fusion_code_key UNIQUE (fusion_code);


--
-- Name: fusions fusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusions
    ADD CONSTRAINT fusions_pkey PRIMARY KEY (id);


--
-- Name: join_annotations join_annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_annotations
    ADD CONSTRAINT join_annotations_pkey PRIMARY KEY (id);


--
-- Name: join_clutch_treatments join_clutch_treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_clutch_treatments
    ADD CONSTRAINT join_clutch_treatments_pkey PRIMARY KEY (id);


--
-- Name: join_dyes_fluorescent_treatments join_dyes_fluorescent_treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_dyes_fluorescent_treatments
    ADD CONSTRAINT join_dyes_fluorescent_treatments_pkey PRIMARY KEY (ft_code, dye_code);


--
-- Name: join_fish_fluorescent_treatments join_fish_fluorescent_treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_fluorescent_treatments
    ADD CONSTRAINT join_fish_fluorescent_treatments_pkey PRIMARY KEY (fish_id, ft_code);


--
-- Name: join_fish_transgene_alleles join_fish_transgene_alleles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_transgene_alleles
    ADD CONSTRAINT join_fish_transgene_alleles_pkey PRIMARY KEY (fish_id, transgene_base_code, allele_number);


--
-- Name: join_plasmid_fusions join_plasmid_fusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_plasmid_fusions
    ADD CONSTRAINT join_plasmid_fusions_pkey PRIMARY KEY (plasmid_id, fusion_id);


--
-- Name: locations locations_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_code_key UNIQUE (code);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: plasmids plasmids_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plasmids
    ADD CONSTRAINT plasmids_code_key UNIQUE (code);


--
-- Name: plasmids plasmids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plasmids
    ADD CONSTRAINT plasmids_pkey PRIMARY KEY (id);


--
-- Name: plate_formats plate_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_formats
    ADD CONSTRAINT plate_formats_pkey PRIMARY KEY (code);


--
-- Name: plate_slots plate_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_slots
    ADD CONSTRAINT plate_slots_pkey PRIMARY KEY (id);


--
-- Name: plates plates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plates
    ADD CONSTRAINT plates_pkey PRIMARY KEY (id);


--
-- Name: plates plates_plate_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plates
    ADD CONSTRAINT plates_plate_code_key UNIQUE (plate_code);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_tag_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_tag_code_key UNIQUE (tag_code);


--
-- Name: tank_pairs tank_pairs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tank_pairs
    ADD CONSTRAINT tank_pairs_pkey PRIMARY KEY (id);


--
-- Name: tank_pairs tank_pairs_tank_pair_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tank_pairs
    ADD CONSTRAINT tank_pairs_tank_pair_code_key UNIQUE (tank_pair_code);


--
-- Name: tanks tanks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tanks
    ADD CONSTRAINT tanks_pkey PRIMARY KEY (id);


--
-- Name: tanks tanks_tank_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tanks
    ADD CONSTRAINT tanks_tank_code_key UNIQUE (tank_code);


--
-- Name: transgene_alleles transgene_alleles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transgene_alleles
    ADD CONSTRAINT transgene_alleles_pkey PRIMARY KEY (transgene_base_code, allele_number);


--
-- Name: transgenes transgenes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transgenes
    ADD CONSTRAINT transgenes_pkey PRIMARY KEY (transgene_base_code);


--
-- Name: treated_clutches treated_clutches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treated_clutches
    ADD CONSTRAINT treated_clutches_pkey PRIMARY KEY (id);


--
-- Name: treatments_chemical treatments_chemical_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments_chemical
    ADD CONSTRAINT treatments_chemical_pkey PRIMARY KEY (ct_code);


--
-- Name: treatments_fluorescent treatments_fluorescent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments_fluorescent
    ADD CONSTRAINT treatments_fluorescent_pkey PRIMARY KEY (ft_code);


--
-- Name: treatments_physical treatments_physical_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments_physical
    ADD CONSTRAINT treatments_physical_pkey PRIMARY KEY (pt_code);


--
-- Name: treatments treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments
    ADD CONSTRAINT treatments_pkey PRIMARY KEY (treat_code);


--
-- Name: join_clutch_treatments uq_jct_by_group_kind_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_clutch_treatments
    ADD CONSTRAINT uq_jct_by_group_kind_code UNIQUE (treated_clutch_id, treatment_type_norm, treatment_code_norm);


--
-- Name: tank_pairs uq_tank_pairs_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tank_pairs
    ADD CONSTRAINT uq_tank_pairs_code UNIQUE (tank_pair_code);


--
-- Name: treated_clutches uq_treated_clutch_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treated_clutches
    ADD CONSTRAINT uq_treated_clutch_code UNIQUE (treated_clutch_code);


--
-- Name: idx_dyes_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dyes_name_ci ON public.dyes USING btree (lower(dye_name));


--
-- Name: idx_fluors_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fluors_name_ci ON public.fluors USING btree (lower(fluor_name));


--
-- Name: ix_jct_clutch_instance_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jct_clutch_instance_id ON public.join_clutch_treatments USING btree (clutch_instance_id);


--
-- Name: ix_jfta_base_num; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jfta_base_num ON public.join_fish_transgene_alleles USING btree (transgene_base_code, allele_number);


--
-- Name: ix_join_annotations_annotation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_join_annotations_annotation ON public.join_annotations USING btree (annotation_id);


--
-- Name: ix_join_annotations_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_join_annotations_target ON public.join_annotations USING btree (target_type, target_id, created_at DESC);


--
-- Name: ix_join_annotations_ttype_tid_aid_val; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_join_annotations_ttype_tid_aid_val ON public.join_annotations USING btree (target_type, target_id, annotation_id, value_num, value_text);


--
-- Name: ix_treated_clutches_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_treated_clutches_ci ON public.treated_clutches USING btree (clutch_instance_id);


--
-- Name: uq_clutches_cross_normgeno; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_clutches_cross_normgeno ON public.clutch_instances USING btree (cross_instance_id, normalized_genotype);


--
-- Name: uq_crosses_pair_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_crosses_pair_date ON public.crosses USING btree (tank_pair_code, cross_date);


--
-- Name: uq_fluors_name_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_fluors_name_lower ON public.fluors USING btree (lower(fluor_name)) WHERE (fluor_name IS NOT NULL);


--
-- Name: uq_ft_proteins_ft_fluor_tag_nd; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ft_proteins_ft_fluor_tag_nd ON public.ft_proteins USING btree (ft_code, fluor_code, tag_code) NULLS NOT DISTINCT;


--
-- Name: uq_ft_proteins_ft_fluor_tag_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ft_proteins_ft_fluor_tag_norm ON public.ft_proteins USING btree (ft_code, COALESCE(tag_code, '∅'::text), fluor_code);


--
-- Name: uq_ft_proteins_ft_tag_fluor; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ft_proteins_ft_tag_fluor ON public.ft_proteins USING btree (ft_code, COALESCE(tag_code, '∅'::text), fluor_code);


--
-- Name: uq_fusions_fluor_tag_nd; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_fusions_fluor_tag_nd ON public.fusions USING btree (fluor_id, COALESCE(tag_id, '00000000-0000-0000-0000-000000000000'::uuid));


--
-- Name: uq_fusions_name_fluor_tag_nd; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_fusions_name_fluor_tag_nd ON public.fusions USING btree (fusion_name, fluor_id, tag_id) NULLS NOT DISTINCT;


--
-- Name: uq_fusions_tag_fluor; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_fusions_tag_fluor ON public.fusions USING btree (tag_id, fluor_id) WHERE ((tag_id IS NOT NULL) AND (fluor_id IS NOT NULL));


--
-- Name: uq_fusions_tag_only; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_fusions_tag_only ON public.fusions USING btree (tag_id) WHERE ((fluor_id IS NULL) AND (tag_id IS NOT NULL));


--
-- Name: uq_join_plasmid_fusions_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_join_plasmid_fusions_ids ON public.join_plasmid_fusions USING btree (plasmid_id, fusion_id);


--
-- Name: uq_join_plasmid_fusions_plasmid_fusion; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_join_plasmid_fusions_plasmid_fusion ON public.join_plasmid_fusions USING btree (plasmid_id, fusion_id);


--
-- Name: uq_plasmids_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_plasmids_code ON public.plasmids USING btree (code);


--
-- Name: uq_plate_slots_loc; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_plate_slots_loc ON public.plate_slots USING btree (plate_id, row_idx, col_idx);


--
-- Name: uq_ta_base_nickname_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ta_base_nickname_norm ON public.transgene_alleles USING btree (transgene_base_code, lower(btrim(allele_nickname)));


--
-- Name: uq_tags_name_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tags_name_lower ON public.tags USING btree (lower(tag_name)) WHERE (tag_name IS NOT NULL);


--
-- Name: uq_tanks_tank_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tanks_tank_code ON public.tanks USING btree (tank_code);


--
-- Name: uq_treated_clutches_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_treated_clutches_code ON public.treated_clutches USING btree (treated_clutch_code);


--
-- Name: v_plasmids _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.v_plasmids AS
 SELECT p.id,
    p.code,
    p.name,
    p.nickname,
    p.resistance,
    p.supports_invitro_rna,
    p.notes,
    p.created_by,
    p.created_at,
    COALESCE(string_agg(DISTINCT fl.fluor_name, ','::text ORDER BY fl.fluor_name), ''::text) AS fluors,
    COALESCE(string_agg(DISTINCT tg.tag_name, ','::text ORDER BY tg.tag_name), ''::text) AS tags,
    COALESCE(string_agg(DISTINCT fu.fusion_name, ','::text ORDER BY fu.fusion_name), ''::text) AS fusions,
    COALESCE(array_agg(DISTINCT fl.fluor_name) FILTER (WHERE (fl.fluor_name IS NOT NULL)), ARRAY[]::text[]) AS fluors_arr,
    COALESCE(array_agg(DISTINCT tg.tag_name) FILTER (WHERE (tg.tag_name IS NOT NULL)), ARRAY[]::text[]) AS tags_arr,
    COALESCE(array_agg(DISTINCT fu.fusion_name) FILTER (WHERE (fu.fusion_name IS NOT NULL)), ARRAY[]::text[]) AS fusions_arr
   FROM ((((public.plasmids p
     LEFT JOIN public.join_plasmid_fusions jpf ON ((jpf.plasmid_id = p.id)))
     LEFT JOIN public.fusions fu ON ((fu.id = jpf.fusion_id)))
     LEFT JOIN public.fluors fl ON ((fl.id = fu.fluor_id)))
     LEFT JOIN public.tags tg ON ((tg.id = fu.tag_id)))
  GROUP BY p.id;


--
-- Name: clutch_instances trg_clutch_instances_bi_assign_fields; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_clutch_instances_bi_assign_fields BEFORE INSERT ON public.clutch_instances FOR EACH ROW EXECUTE FUNCTION public.clutch_instances_bi_assign_fields();


--
-- Name: crosses trg_crosses_bi_assign_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_crosses_bi_assign_code BEFORE INSERT ON public.crosses FOR EACH ROW EXECUTE FUNCTION public.crosses_bi_assign_code();


--
-- Name: fish trg_fish_code_default; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fish_code_default BEFORE INSERT ON public.fish FOR EACH ROW EXECUTE FUNCTION public.trg_set_fish_code_from_uuid_base36_8();


--
-- Name: ft_proteins trg_ft_proteins_normalize; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ft_proteins_normalize BEFORE INSERT ON public.ft_proteins FOR EACH ROW EXECUTE FUNCTION public.ft_proteins_normalize_codes();


--
-- Name: fusions trg_fusions_set_code_before_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fusions_set_code_before_insert BEFORE INSERT ON public.fusions FOR EACH ROW EXECUTE FUNCTION public.fusions_set_code_before_insert();


--
-- Name: join_annotations trg_ja_biu_enforce_scale_100; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ja_biu_enforce_scale_100 BEFORE INSERT OR UPDATE ON public.join_annotations FOR EACH ROW EXECUTE FUNCTION public.ja_biu_enforce_scale_100();


--
-- Name: join_clutch_treatments trg_jct_bi_assign_group; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_jct_bi_assign_group BEFORE INSERT ON public.join_clutch_treatments FOR EACH ROW EXECUTE FUNCTION public.jct_bi_assign_group();


--
-- Name: join_clutch_treatments trg_jct_bi_norm; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_jct_bi_norm BEFORE INSERT OR UPDATE ON public.join_clutch_treatments FOR EACH ROW EXECUTE FUNCTION public.jct_bi_norm();


--
-- Name: plates trg_plates_bi_assign_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_plates_bi_assign_code BEFORE INSERT ON public.plates FOR EACH ROW EXECUTE FUNCTION public.plates_bi_assign_code();


--
-- Name: tank_pairs trg_tank_pairs_bi_assign_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tank_pairs_bi_assign_code BEFORE INSERT ON public.tank_pairs FOR EACH ROW EXECUTE FUNCTION public.tank_pairs_bi_assign_code();


--
-- Name: tanks trg_tanks_bi_set_defaults; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tanks_bi_set_defaults BEFORE INSERT ON public.tanks FOR EACH ROW EXECUTE FUNCTION public.tanks_bi_set_defaults();


--
-- Name: clutch_instances trg_tc_ai_baseline; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tc_ai_baseline AFTER INSERT ON public.clutch_instances FOR EACH ROW EXECUTE FUNCTION public.treated_clutches_ai_baseline();


--
-- Name: treated_clutches trg_treated_clutches_bi_assign_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_treated_clutches_bi_assign_code BEFORE INSERT ON public.treated_clutches FOR EACH ROW EXECUTE FUNCTION public.treated_clutches_bi_assign_code();


--
-- Name: clutch_instances clutch_instances_cross_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clutch_instances
    ADD CONSTRAINT clutch_instances_cross_instance_id_fkey FOREIGN KEY (cross_instance_id) REFERENCES public.crosses(id) ON DELETE CASCADE;


--
-- Name: join_fish_transgene_alleles fk_jfta_ta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_transgene_alleles
    ADD CONSTRAINT fk_jfta_ta FOREIGN KEY (transgene_base_code, allele_number) REFERENCES public.transgene_alleles(transgene_base_code, allele_number);


--
-- Name: ft_dyes ft_dyes_dye_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_dyes
    ADD CONSTRAINT ft_dyes_dye_code_fkey FOREIGN KEY (dye_code) REFERENCES public.dyes(dye_code) ON DELETE CASCADE;


--
-- Name: ft_dyes ft_dyes_ft_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_dyes
    ADD CONSTRAINT ft_dyes_ft_code_fkey FOREIGN KEY (ft_code) REFERENCES public.treatments_fluorescent(ft_code) ON DELETE CASCADE;


--
-- Name: ft_proteins ft_proteins_fluor_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_proteins
    ADD CONSTRAINT ft_proteins_fluor_code_fkey FOREIGN KEY (fluor_code) REFERENCES public.fluors(fluor_code);


--
-- Name: ft_proteins ft_proteins_ft_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_proteins
    ADD CONSTRAINT ft_proteins_ft_code_fkey FOREIGN KEY (ft_code) REFERENCES public.treatments_fluorescent(ft_code) ON DELETE CASCADE;


--
-- Name: ft_proteins ft_proteins_tag_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ft_proteins
    ADD CONSTRAINT ft_proteins_tag_code_fkey FOREIGN KEY (tag_code) REFERENCES public.tags(tag_code);


--
-- Name: fusions fusions_dye_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusions
    ADD CONSTRAINT fusions_dye_id_fkey FOREIGN KEY (dye_id) REFERENCES public.dyes(id);


--
-- Name: fusions fusions_fluor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusions
    ADD CONSTRAINT fusions_fluor_id_fkey FOREIGN KEY (fluor_id) REFERENCES public.fluors(id);


--
-- Name: fusions fusions_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusions
    ADD CONSTRAINT fusions_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: join_annotations join_annotations_annotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_annotations
    ADD CONSTRAINT join_annotations_annotation_id_fkey FOREIGN KEY (annotation_id) REFERENCES public.annotations(id) ON DELETE CASCADE;


--
-- Name: join_clutch_treatments join_clutch_treatments_clutch_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_clutch_treatments
    ADD CONSTRAINT join_clutch_treatments_clutch_instance_id_fkey FOREIGN KEY (clutch_instance_id) REFERENCES public.clutch_instances(id) ON DELETE CASCADE;


--
-- Name: join_clutch_treatments join_clutch_treatments_treated_clutch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_clutch_treatments
    ADD CONSTRAINT join_clutch_treatments_treated_clutch_id_fkey FOREIGN KEY (treated_clutch_id) REFERENCES public.treated_clutches(id) ON DELETE CASCADE;


--
-- Name: join_dyes_fluorescent_treatments join_dyes_fluorescent_treatments_dye_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_dyes_fluorescent_treatments
    ADD CONSTRAINT join_dyes_fluorescent_treatments_dye_code_fkey FOREIGN KEY (dye_code) REFERENCES public.dyes(dye_code);


--
-- Name: join_dyes_fluorescent_treatments join_dyes_fluorescent_treatments_ft_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_dyes_fluorescent_treatments
    ADD CONSTRAINT join_dyes_fluorescent_treatments_ft_code_fkey FOREIGN KEY (ft_code) REFERENCES public.treatments_fluorescent(ft_code) ON DELETE CASCADE;


--
-- Name: join_fish_fluorescent_treatments join_fish_fluorescent_treatments_fish_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_fluorescent_treatments
    ADD CONSTRAINT join_fish_fluorescent_treatments_fish_id_fkey FOREIGN KEY (fish_id) REFERENCES public.fish(id) ON DELETE CASCADE;


--
-- Name: join_fish_fluorescent_treatments join_fish_fluorescent_treatments_ft_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_fluorescent_treatments
    ADD CONSTRAINT join_fish_fluorescent_treatments_ft_code_fkey FOREIGN KEY (ft_code) REFERENCES public.treatments_fluorescent(ft_code) ON DELETE CASCADE;


--
-- Name: join_fish_transgene_alleles join_fish_transgene_alleles_fish_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_transgene_alleles
    ADD CONSTRAINT join_fish_transgene_alleles_fish_id_fkey FOREIGN KEY (fish_id) REFERENCES public.fish(id) ON DELETE CASCADE;


--
-- Name: join_fish_transgene_alleles join_fish_transgene_alleles_transgene_base_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_fish_transgene_alleles
    ADD CONSTRAINT join_fish_transgene_alleles_transgene_base_code_fkey FOREIGN KEY (transgene_base_code) REFERENCES public.transgenes(transgene_base_code) ON DELETE CASCADE;


--
-- Name: join_plasmid_fusions join_plasmid_fusions_fusion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_plasmid_fusions
    ADD CONSTRAINT join_plasmid_fusions_fusion_id_fkey FOREIGN KEY (fusion_id) REFERENCES public.fusions(id) ON DELETE CASCADE;


--
-- Name: join_plasmid_fusions join_plasmid_fusions_plasmid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_plasmid_fusions
    ADD CONSTRAINT join_plasmid_fusions_plasmid_id_fkey FOREIGN KEY (plasmid_id) REFERENCES public.plasmids(id) ON DELETE CASCADE;


--
-- Name: plate_slots plate_slots_plate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_slots
    ADD CONSTRAINT plate_slots_plate_id_fkey FOREIGN KEY (plate_id) REFERENCES public.plates(id) ON DELETE CASCADE;


--
-- Name: plate_slots plate_slots_treated_clutch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_slots
    ADD CONSTRAINT plate_slots_treated_clutch_id_fkey FOREIGN KEY (treated_clutch_id) REFERENCES public.treated_clutches(id);


--
-- Name: plates plates_format_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plates
    ADD CONSTRAINT plates_format_code_fkey FOREIGN KEY (format_code) REFERENCES public.plate_formats(code);


--
-- Name: tank_pairs tank_pairs_father_tank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tank_pairs
    ADD CONSTRAINT tank_pairs_father_tank_id_fkey FOREIGN KEY (father_tank_id) REFERENCES public.tanks(id) ON DELETE SET NULL;


--
-- Name: tank_pairs tank_pairs_mother_tank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tank_pairs
    ADD CONSTRAINT tank_pairs_mother_tank_id_fkey FOREIGN KEY (mother_tank_id) REFERENCES public.tanks(id) ON DELETE SET NULL;


--
-- Name: tanks tanks_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tanks
    ADD CONSTRAINT tanks_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: transgene_alleles transgene_alleles_transgene_base_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transgene_alleles
    ADD CONSTRAINT transgene_alleles_transgene_base_code_fkey FOREIGN KEY (transgene_base_code) REFERENCES public.transgenes(transgene_base_code) ON DELETE CASCADE;


--
-- Name: treated_clutches treated_clutches_clutch_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treated_clutches
    ADD CONSTRAINT treated_clutches_clutch_instance_id_fkey FOREIGN KEY (clutch_instance_id) REFERENCES public.clutch_instances(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Lgo2O0ednJ7eIg10vMrj4940YRdasAFbpMXr5ObWeWczihQtzQp2wK5YY6a9wYO

