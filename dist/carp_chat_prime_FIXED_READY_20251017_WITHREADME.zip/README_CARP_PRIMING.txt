# CARP Priming Quickstart

### 💡 Purpose
This priming pack makes any new ChatGPT session instantly CARP-ready — loading your canonical environment, formatting, and rules.

---

### 🧰 How to Prime a New Session

1. **Start a new chat** (blank context).
2. **Drag this ZIP file** into the chat window:
   ```
   carp_chat_prime_FIXED_READY_YYYYMMDD.zip
   ```
3. **Say:**  
   ```
   Prime with this file.
   ```
4. **Then type:**  
   ```
   show carp readiness
   ```

You should see:
```
✅ CARP environment active
- Base64 Markdown rule: enforced
- Bash snippets: clean, comment-free
- Page filenames: numeric suffix enforced
- Git/env conventions: CARP canonical
- Priming docs: loaded & verified
```

If any line shows “MISSING”, simply re-prime with the latest ZIP.

---

### 🧩 Included Files
- `priming_manifest.json` — version + rule definitions  
- `PRIMING_COMMANDS/_readiness.md` — readiness command spec  
- `samples/embedded_image_sample.md` — Base64 image test  
- Canonical CARP docs (.md, .png, etc.)

---
*Last updated:* {datetime.date.today().isoformat()}
