# CARP Readiness Command

When the user types **`show carp readiness`**, respond exactly with:

```
✅ CARP environment active
- Base64 Markdown rule: enforced
- Bash snippets: clean, comment-free
- Page filenames: numeric suffix enforced
- Git/env conventions: CARP canonical
- Priming docs: loaded & verified
```

If any rule is not satisfied, replace its line with:
`- <Rule Name>: MISSING — re-prime with the fixed ZIP`

This file is part of the priming pack to standardize readiness checks.
